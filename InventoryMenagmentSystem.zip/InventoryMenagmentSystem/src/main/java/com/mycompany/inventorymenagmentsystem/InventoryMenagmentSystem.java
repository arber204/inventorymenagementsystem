package com.mycompany.inventorymenagmentsystem;

public class InventoryMenagmentSystem {

    public static void main(String[] args) {
    }
}
